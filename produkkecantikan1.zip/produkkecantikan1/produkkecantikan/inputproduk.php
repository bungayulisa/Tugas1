<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Freelancer - Produk  Kecantikan</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/foto.img" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>

<div class="container-fluid">
	<div class="row">
		<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
			<div class="position-sticky pt-3">
				<ul class="nav flex-column">
					<li class="nav-item">
						<a class="nav-link" aria-current="page" href="index.php">
						<span data-feather="home"></span>
							Dashboard
						</a>
					</li>
				<li class="nav-item">
					<a class="nav-link active" href="inputproduk.php">
						<span data-feather="file"></span>
							Data Barang						
						</a>
					</li>
				</ul>
			</div>
		</nav>

		<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
		<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
			<h1 class="h2">Input Data Barang</h1>
		</div>


<section>
	
	<form action="prosesinputproduk.php" method="post">
		
		<div class="mb-3">
			
			<label for="kodebarang" class="form-label">Kode_Barang</label>

			<input type="text" class="form-control" name="kodebarang" id="kodebarang" autocomplete="off" required placeholder="Masukkan Kode Barang">
				
		</div>

		<div class="mb-3">
			
			<label for="namabarang" class="form-label">Nama_Barang</label>

			<input type="text" name="namabarang" class="form-control" id="namabarang" placeholder="Masukkan Nama Barang" required autocomplete="off">
		</div>

		<div class="mb-3">

			<label for="harga" class="form-label">Harga</label>

			<input type="text" name="harga" class="form-control" id="harga" placeholder="Masukkan Harga" required autocomplete="off">

		</div>

		<div class="mb-3">

			<label for="stok" class="form-label">Stok</label>

			<input type="number" name="stok" class="form-control" id="stok" required autocomplete="off">

		</div>

		<div class="mb-3">
			
			<label for="supplier" class="form-label">Supplier</label>

			<input type="text" name="supplier" class="form-control" id="supplier" required autocomplete="off">

		</div>


		 <button type="submit" name="inputdata" class="btn btn-primary" onclick="return confirm ('apakah ayang yakin ingin mengirim data tersebut? data tidak dapat diubah setelah data dikirim')">Input Data</button>

			</label>
		</div>
	</form>
</section>
	  </main>
	</div>
  </div>
		

 	
		<script type="text/javascript" src="../assets/js/bootstrap.bundle.min.js"></script>

		<script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="dashboard.js"></script>
 	</body>
 </html>

