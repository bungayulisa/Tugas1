<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Freelancer - Produk  Kecantikan</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/foto.img" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>

<div class="container-fluid">
	<div class="row">
		<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
			<div class="position-sticky pt-3">
				<ul type="disc" class="nav flex-column">
					<li class="nav-item">
						<a class="nav-link active" aria-current="page" href="index.php">
							<span data-feather="home"></span>
							Dashboard
						</a>
                        <li class="nav-item">
                    <a class="nav-link active" href="dataproduk.php">
                        <span data-feather="file"></span>
                            Data Barang                     
                        </a>
                        <a class="nav-link active" href="index.php">
                        <span data-feather="file"></span>
                            Home                     
                        </a>
                    </li>
				</ul>
			</div>
		</nav>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
      <h1 class="h2">Data Suplier</h1>
    </div>

    <h4>
      <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mengenal Tabel HTML</title>
    <style>
        table {
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
        }
        th {
            background-color: #808080;
            color: dark blue;
        }
    </style>
</head>
<body>
    <table>
        <tr>
            <th rowspan="2">No</th>
            <th colspan="5"><center>Data Kosmetik</center>
            </th>
        </tr>
        <tr>
            <th>ID</th>
            <th>Nama Barang</th>
            <th>Jumlah</th>
            <th>Merk</th>
            <th>Harga</th>
        </tr>
        <tr>
            <td>1</td>
            <td>12345</td>
            <td>Lipstik</td>
            <td>15</td>
            <td>Wardah</td>
            <td>Rp 20.000</td>
        </tr>
        <tr>
            <td>2</td>
            <td>09876</td>
            <td>Mascara</td>
            <td>14</td>
            <td>Wardah</td>
            <td>Rp 22.000</td>
        </tr>
        <tr>
            <td>3</td>
            <td>56789</td>
            <td>Bedak</td>
            <td>13</td>
            <td>Wardah</td>
            <td>Rp 25.000</td>
        </tr>
         <tr>
            <td>4</td>
            <td>12367</td>
            <td>Pensil Alis</td>
            <td>12</td>
            <td>Wardah</td>
            <td>Rp 30.000 </td>
         <tr>
            <td>5</td>
            <td>87643</td>
            <td>Blush On</td>
            <td>11</td>
            <td>Wardah</td>
            <td>Rp 15.000</td>
        </tr>
        <tr>
            <td>5</td>
            <td>56478</td>
            <td>Eyeliner</td>
            <td>10</td>
            <td>Wardah</td>
            <td>Rp 24.000</td>
        </tr>
    </table>
</body>
    </h4>
    </main>
  </div>
</div>

		<script type="text/javascript" src="../assets/js/bootstrap.bundle.min.js"></script>

		<script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="dashboard.js"></script>
 	</body>
 </html>