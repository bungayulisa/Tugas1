<?php

 include 'koneksi.php';
  $id = $_POST['id'];
  $kodebarang = $_POST['Kode_Barang'];
  $namabarang = $_POST['Nama_Barang'];
  $harga = $_POST['Harga'];
  $stok = $_POST['Stok'];
  $supplier = $_POST['Supplier'];



  mysqli_query($dbconnect, "UPDATE `kecantikan` SET `Kode_Barang`='$kodebarang' , `Nama_Barang`='$namabarang' , `Harga`='$harga' , `Stok`='$stok', `Supplier`='$supplier' WHERE `id`='$id' ");
  header("location:dataproduk.php");
  ?>