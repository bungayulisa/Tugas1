<?php

include 'koneksi.php';

$kodebarang= $_POST['kodebarang'];
$namabarang= $_POST['namabarang'];
$harga= $_POST['harga'];
$stok= $_POST['stok'];
$supplier= $_POST['supplier'];



 mysqli_query($dbconnect, "INSERT INTO kecantikan VALUES ( NULL, '$kodebarang','$namabarang','$harga','$stok','$supplier')");

 header("location:dataproduk.php")
 ?>